<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
    <meta charset="UTF-8">
</head>
<body>
<h1>2222</h1>

<?php if(is_array($folder)): foreach($folder as $key=>$li): ?><a href="<?php echo U('file/showfile',array('folder'=>$li['filesavefolder']));?>"><?php echo ($li["filesavefolder"]); ?></a>
    <br><?php endforeach; endif; ?>


</body>
</html>