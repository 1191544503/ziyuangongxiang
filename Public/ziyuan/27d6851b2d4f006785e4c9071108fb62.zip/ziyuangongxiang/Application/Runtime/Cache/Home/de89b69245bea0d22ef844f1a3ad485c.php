<?php if (!defined('THINK_PATH')) exit();?><!--<html>-->
<!--<head>-->
    <!--<meta charset="UTF-8">-->
<!--</head>-->
<!--<body>-->
<!--<h1>文件上传<h1>-->
    <!--<form action = "<?php echo U('File/up');?>" method="post" enctype="multipart/form-data">-->
    <!--<input type="file" name="upfile"/><input type="submit"/>-->
   <!--</form>-->

<!--</body>-->
<!--</html>-->


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>文件上传</title>
    <link rel="stylesheet" type="text/css" href="/test/Public/CSS/upload.css">
    <script type="text/javascript" src="/jquery.min.js"></script>
</head>
<body>
<div id="body">
    <div id="page">
        <br>
        <div id="title"><h1>文件上传</h1></div>
        <form action = "<?php echo U('File/up');?>" method="post" enctype="multipart/form-data">
            <input type="radio" id="T1" name="filetype" value="teacherfile" checked onchange="fun()"/><label for="T1">教师文件</label>
            <input type="radio" id="T2" name="filetype" value="testdata"  onchange="fun()"/><label for="T2">测试数据</label>
            <br>
            <br>
            <div id="testfile" style="display: none;">
                题目编号及名字：<input type="text" name="testfilename">
            </div>
            <br>
            <br>
            <input type="file" name="upfile" id="files" >
            <input type="submit" name="submitBtn" value="提交">
        </form>
    </div>
</div>
</body>
</html>
<script>
    function fun() {
        var tt = document.getElementsByName('filetype')
        if (tt[0].checked) {
            document.getElementById('testfile').style.display="none";
        }
        else if (tt[1].checked) {
            document.getElementById('testfile').style.display="block";
        }
    }
</script>