<?php if (!defined('THINK_PATH')) exit();?><!--<html>-->
<!--<head>-->
    <!--<meta charset="UTF-8">-->
<!--</head>-->
<!--<body align="center">-->
<!--<h1>33333</h1>-->

<!--<?php if(is_array($result)): foreach($result as $key=>$li): ?>-->
    <!--<a href="<?php echo U('File/downloadFile',array('folders'=>$li['filesavefolder'],'file'=>$li['filesavename'],'reallyfile'=>$li['filename']));?>"><?php echo ($li["filename"]); ?></a>-->
    <!--&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($li["upfile_time"]); ?>&nbsp &nbsp-->
    <!--<a href="<?php echo U('File/onlineShow',array('folders'=>$li['filesavefolder'],'file'=>$li['filesavename'],'reallyfile'=>$li['filename']));?>">在线浏览</a>-->
    <!--&nbsp;&nbsp;&nbsp;&nbsp;-->

    <!--<br>-->
<!--<?php endforeach; endif; ?>-->

<!--</body>-->
<!--</html>-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="/test/Public/CSS/index.css">
</head>
<body>
<article class="">
    <div class="list">
        <span>文件名</span>
        <span>上传时间</span>
        <span>上传人</span>
    </div>
    <hr />

    <section>

        <ul>
            <?php if(is_array($result)): foreach($result as $key=>$li): ?><li>
                <div class="list">
                    <span><a href="<?php echo U('File/downloadFile',array('folders'=>$li['filesavefolder'],'file'=>$li['filesavename'],'reallyfile'=>$li['filename'],'fileusername'=>$li['username']));?>" style="color:blue;"><?php echo ($li["filename"]); ?></a></span>
                    <span><a href=""><?php echo ($li["upfile_time"]); ?></a></span>
                    <span><a href=""><?php echo ($li["fileusername"]); ?></a></span>
                </div>
            </li><?php endforeach; endif; ?>
        </ul>
    </section>
</article>
</body>
</html>