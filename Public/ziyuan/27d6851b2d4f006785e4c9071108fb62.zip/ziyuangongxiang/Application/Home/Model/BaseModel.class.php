<?php
/**
 * Created by PhpStorm.
 * User: acm
 * Date: 2017/9/25
 * Time: 15:14
 */
namespace Home\Model;
use Think\Model;

class BaseModel extends  Model{

}
?>