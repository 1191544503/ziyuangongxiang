<?php
/**
 * Created by PhpStorm.
 * User: acm
 * Date: 2017/9/25
 * Time: 15:14
 */
namespace Home\Model;
use Think\Model;

class FileModel extends  BaseModel{
    public function insertData($data){
        if($this->data($data)->add()){
            return true;
        }else{
            return false;
        }
    }

    public function queryData(){
        $result = $this->where(1)->query();
        return $result;
    }

    public function queryDataByUsername($username){
        $result = $this->where("fileusername='{$username}'and isdelete=0 and filesavefolder='ziyuan'")->select();
        return $result;
    }

    public function queryAllUsername(){
        $result = $this->distinct(true)->field('fileusername')->where("filesavefolder='ziyuan'")->select();
        return $result;
    }

    public function queryFileByFolder($folder){
        $result = $this->field('filename,filesavename,upfile_time,filesavefolder,fileusername')->where("filesavefolder='{$folder}' and isdelete=0")->select();
        return $result;
    }

    public function deleteFile($filesavename){
        $sql = "update file set isdelete=1 where filesavename='{$filesavename}'";
        if($this->execute($sql)){
            return true;
        }else{
            return false;
        }
    }

    public function addCount($file){
        $sql="update file set file.count=file.count+1 where filesavename ='{$file}'";
        $this->execute($sql);
    }

    public function queryFileByUsername($username){
        $result = $this->field('count,filename,filesavename,upfile_time,filesavefolder,fileusername')->where("fileusername='{$username}'and isdelete=0")->select();
        return $result;
    }
}
?>