<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        session('username',I('get.username'));
        session('isteacher',I('get.is'));
        $fileModel = D('file');
        $result = $fileModel->queryAllUsername();

        $this->assign(fileusername,$result);
        $this->display('Index/index');
    }
}