<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller {
    public function userinfo(){
        $fileModel = D('file');
        $username=session('username');
        $result=$fileModel->queryFileByUsername($username);
        $this->assign('result',$result);
        $this->display('userinfo');
    }

    /**
     * 文件删除
     */
    public function deleteFile(){
        $filesavename = I('get.filesavename');
        $fileModel = D('file');
        if($fileModel->deleteFile($filesavename)){
            echo "成功删除";
        }else{
            echo "删除失败";
        }
    }

}