<?php
namespace Home\Controller;
use Think\Controller;
header("content-type:text/html;charset=utf-8");
class FileController extends BaseController{
    public function displayup(){
        $this->display('upfile');
    }

//    public function showfolder(){
//        $fileModel = D('file');
//        $result = $fileModel->queryAllFolder();
//        $this->assign(folder,$result);
//        $this->display('folder');
//    }

    public function showfile(){
        $fileModel = D('file');
        $filefolder=I('get.filesavefolder');

        if($filefolder=="ziyuan") {
            $fileusername = I('get.fileusername');
            $result = $fileModel->queryDataByUsername($fileusername);
            //  print_r($result)
        }
        elseif($filefolder=="testdata"){
            $result=$fileModel->queryFileByFolder($filefolder);
        }
        $this->assign(result,$result);
        $this->display('showfile');
}

    /**
     * 处理前端发来的文件信息
     */

    public function up(){
        $file= $_FILES['upfile'];
        $username = session('username');
        $uptype=I('post.filetype');
        if($uptype=="teacherfile"){//上传正常教师文件
            $filename=$file['name'];
            $data['filesavefolder'] = "ziyuan";
        }
        elseif($uptype=="testdata"){//上传测试数据文件
            $filename=I('post.testfilename');
            $data['filesavefolder'] = "testdata";
            $filename = $this->subFilename($file['name'],$filename);//将后输入的文件名拼接后缀
        }
        $filenamemd5=$this->md5FileName($filename,date(Y-m-d));
        $filesavename = $this->subFilename($filename,$filenamemd5);
        $data['fileusername'] = $username;
        $data['filename'] = $filename;
        $data['filetype'] = $file['type'];
        $data['filesavename'] = $filesavename;
        $data['isdelete'] = 0;
        $data['count'] = 0;
        $data['upfile_time'] = date("Y-m-d");
        $fileModel = D('file');

        if($this->upFile($file,$filenamemd5,$data['filesavefolder'])){
            if($fileModel->insertData($data)) {
                echo "上传成功";
            }else{
                echo "上传失败";
            }
        }else{
            echo "上传失败";
        }
    }



    /**
     * 文件上传函数
     * 参数 文件信息 保存的件名 保存的文件夹
     */
    public function upFile($file,$filename,$folders){
        $folders = iconv("utf-8","GBK",$folders);
        $path='./Public/'.$folders.'/';
        if(!file_exists($path)){
            mkdir($path);
        }

        $upload = new \Think\Upload();
        $upload->maxSize=3145728000;
        $upload->autoSub=false;
        $upload->rootPath=$path;
        $upload->saveName = $filename;
        $upload->exts = array('jpg','jpeg','zip','doc','sql','txt','docx','png','ppt','gif','bmp','mp4','avi','.in','.out');
        $upload->uploadReplace = false;

        $info = $upload->uploadOne($file);

        if($info){
            return true;
        }else{
            $this->error=$upload->getError();
            echo $this->error;
            return false;
        }
}
     /**
      * 文件下载函数
      *
      */
 public function downloadFile(){
        $folders=I('get.folders');
        $file = I('get.file');
        $reallyfile=I('get.reallyfile');

        echo $file;
        $reallyfile=urlencode($reallyfile);
        $file = iconv("utf-8","GBK",$file);
        $url ='C:/AppServ/www/test/Public/'.$folders.'/'.$file;
        echo  $url;
        import('Org.Net.Http');
        $fileModel=D('file');
        $fileModel->addCount($file);

        $http=new \Org\Net\Http;
        $http->download($url,$reallyfile);
 }
    /**
     *
     */
    public function onlineShow()
    {
        $folders = I('get.folders');
        $file = I('get.file');
        $reallyfile = I('get.reallyfile');
        $len=strlen($reallyfile);
        if($reallyfile[$len-3]=='t'&&$reallyfile[$len-2]=='x'&&$reallyfile[$len-1]=='t'||1) {

            $reallyfile = urlencode($reallyfile);
        //    $folders = iconv("utf-8", "GBK", $folders);
            $file = iconv("utf-8", "GBK", $file);
            $url = 'C:/AppServ/www/test/Public/'.$folders.'/'.$file;
            /////读出文件内容，显示到前端
            ///
            ///
            if (file_exists($url)) {
                $str = file_get_contents($url);//将整个文件内容读入到一个字符串中
                $str = str_replace("\r\n", "<br />", $str);
                $str = iconv("gb2312", "utf-8//IGNORE", $str);
                echo $str;

            }
        }else{
            echo "该文件类型暂不支持在线浏览";
        }
    }
    /**
     *文件命名MD5加密
     */
 public function md5FileName($filename ,$date){
        $random=rand(1001,9999999);
        $filename.=$date;
        $filename.=$random;

        for($i=0;$i<15;$i++) {
            $filename = md5($filename);
        }

        return $filename;
 }
    /**
     * 文件名后缀拼接
     */
 public function subFilename($filename,$filesavename){

     $filesavename.=strchr($filename,".");
     return $filesavename;
 }

}
?>