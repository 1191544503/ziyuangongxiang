<?php
return array(
	//'配置项'=>'配置值'
    'DB_TYPE' =>'mysql',
    'DB_HOSE' =>'localhost',
    'DB_USER' =>'root',
    'DB_PWD' =>'11915445',
    'DB_NAME' =>'ziyuan',
    'DB_PORT' =>3306,
);
/*
create table file(
 filename char(100),
 filetype char(100),
 filesavename char(150),
 fileusername char(50),
 filesavefolder char(30),
 isdelete int,
 count int,
 upfile_time date
);

*/