create table file(
 filename char(100),
 filetype char(100),
 filesavename char(150),
 fileusername char(50),
 filesavefolder char(30),
 isdelete int
);